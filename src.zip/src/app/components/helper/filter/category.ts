export interface Category {
    id: string;
    title: string;
}