import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flights-details',
  templateUrl: './flights-details.component.html',
  styleUrls: ['./flights-details.component.css']
})
export class FlightsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
