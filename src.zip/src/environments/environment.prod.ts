export const environment = {
  production: true,
  appShellConfig: {
    debug: false,
    networkDelay: 0
  },
  // apiUrl:"https://api.skypicker.com/",
  // baseUrl : "https://www.khalsatravel.net/flight/api/",
  // baseUrl3:"https://www.khalsatravel.net/agent/"
  apiUrl:"https://api.skypicker.com/",
  baseUrl : "https://www.khalsatravel.net/index.php/flight/api/",
  baseUrl2:"https://www.khalsatravel.net/agent/"
};
